<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SeminarkitSPKController extends Controller
{
    //
}
