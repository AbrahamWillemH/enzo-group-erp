<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SeminarKitController extends Controller
{
    public function seminarkitDetails($id){

    }
}
